import React, { Component } from 'react';
import { connect } from 'react-redux';
import { postRecord } from '../store/action/postAction';

class PostFrom extends Component {
    state = { 
        title:"",
        body:""
     }
     componentWillReceiveProps(nextProps) {
        if (nextProps.itemLoaded) {
            this.props.dummy[0]="sdsdsd"
        }
    }
    onchangeUpdate = (e) => {
        this.setState({[e.target.name] : e.target.value})
    };
    UpdatePost = (e) => {
        e.preventDefault();

        const postData = {
            title : this.state.title,
            body : this.state.body
        }
       this.props.postRecord(postData);
    };
    propsloaded() {
        let content = <span>Props loaded {this.props.itemLoaded.id} </span>;
        if(this.props.itemLoaded) {
            return content;
        }
    }
    render() { 
        return ( 
            <div>
                {this.propsloaded()} --- { this.props.dummy.toString()}
                <h1>Add Post</h1>
                <form action="javascript:void(0)">
                    <div>
                        <label>Title: </label> <br/>
                        <input autoComplete="off" onChange={this.onchangeUpdate} className="form-control" name="title" type="text" value={this.state.title} />
                    </div>
                    <div>
                        <label>Body: </label> <br/>
                        <textarea   className="form-control" onChange={this.onchangeUpdate} name="body" value={this.state.body}/>
                    </div>
                    <div>
                        <button onClick={this.UpdatePost} className="btn btn-primary m-1">Submit</button>
                    </div>
                </form>
            </div>
         );
    }
}

const mapStateToProps = state => ({
    itemLoaded:state.yasar.item,
    dummy:state.yasar.dummy
});

export default connect(mapStateToProps,{postRecord})(PostFrom);