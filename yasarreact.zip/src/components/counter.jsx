import React, { Component}  from 'react';
const Counter = (props) => {

   const classNameRender = () => {
        const {counter}  = props.value;
        let classRender = "badge m-2 badge-";
        return classRender += counter == 0 ? "warning":"primary";
   };

    const formatCount = () => {
        const {counter} = props.value;
        return counter == 0 ? 'Zero' : counter;
    };

    return (
    <div>
        <h1>Counter #{props.value.id}</h1>
        <span className={classNameRender()}>{formatCount()}</span>
        <button className="btn btn-secondary btn-sm m-2" onClick={props.handleIncre}>Increment</button>
        <button className="btn btn-secondary btn-sm" onClick={props.handleDel}>Delete</button>
    </div>);

}
 
export default Counter;