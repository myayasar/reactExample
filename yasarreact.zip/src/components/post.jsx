import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchRecord } from '../store/action/postAction';

class Posts extends Component {
    componentWillMount() {
       this.props.fetchRecord();
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.item) {
            this.props.posts.unshift(nextProps.item)
        }
    }
    render() {
        const postData = this.props.posts.map(post =>
            <div key={post.id}>
            <h2>{post.title}</h2>
            <span>{post.body}</span>
            </div>
        ) 
        return ( 
            <div>
                <h1>Post</h1>
                {postData}
            </div>
         );
    }
}

const mapStateToProps = state => ({
    posts: state.yasar.items,
    item: state.yasar.item
  });

export default connect(mapStateToProps,{ fetchRecord })(Posts);