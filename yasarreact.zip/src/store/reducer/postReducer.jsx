import {FETCH_POST,NEW_POST} from "../types";

const init = {
    items : [],
    item : {},
    dummy : [1,2,3]
};

export default function(state = init, action) {
    switch (action.type) {
        case FETCH_POST:
            return {
                ...state,
                items : action.payload
            };
        case NEW_POST: 
            return {
                ...state,
                item : action.payload
            }
        default:
            return state;
    };
};