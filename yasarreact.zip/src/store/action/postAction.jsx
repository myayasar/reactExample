import {FETCH_POST,NEW_POST} from "../types";

export const fetchRecord = () => dispatch => {
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res => res.json())
    .then(posts =>dispatch({
        type:FETCH_POST,
        payload:posts
    }));
};

export const postRecord = (postData) => dispatch => {
    console.log(dispatch)
    fetch("https://jsonplaceholder.typicode.com/posts",{
            method:"POST",
            headers:{
                "content-type":"application/json"
            },
            body : JSON.stringify(postData)
        })
        .then(res => res.json())
        .then(posts =>dispatch({
            type:NEW_POST,
            payload:posts
        }))
};

