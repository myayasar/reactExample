export const FETCH_POST = "GET_POST";
export const NEW_POST = "SET_POST";