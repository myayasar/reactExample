import React, { Component } from 'react';
import './App.css';
import { Provider } from 'react-redux';

import Counter from "./components/counter";
import Posts from "./components/post";
import PostForm from "./components/postform";
import store from './store';


class App extends Component {
  state = {
    count:[
      {id:1,counter:23},
      {id:2,counter:0}
    ]
  };
  render() {
    return (
      <Provider store={store}>
        <div className="m-5">
         {this.state.count.map(count => 
         <Counter key={count.id} value={count} handleIncre={()=>this.countIncre(count)} handleDel={()=>this.handleDel(count)} />
         )}
         <PostForm/>
         <hr/>
          <Posts/>
        </div>
        </Provider>
    );
  }
  handleDel = (count) => {
    let counter = [...this.state.count];
    let index = counter.indexOf(count);
    counter.splice(index,1);
    this.setState({count:counter})
  }
  countIncre = (count) => {
    let counter = [...this.state.count];
    let index = counter.indexOf(count);
    counter[index] = {...count};
    counter[index].counter++;
    console.log(counter,counter);
    this.setState({count : counter});
  };
}

export default App;
